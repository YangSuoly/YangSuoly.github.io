---
spec_version: "1.0"
type: llm-feature
priority: high
---

# [功能名称]

## 概述
[功能描述，说明这个 LLM 功能的用途]

## LLM 配置

### 模型选择
- **提供商**: OpenAI / Anthropic / 智谱 AI
- **模型名称**: glm-4.7 / gpt-4 / claude-3-opus-200k
- **温度**: 0.3-0.7（根据任务调整）
- **最大 Token**: 2000-4000

### 提示词策略
- **提示词文件**: `src/prompts/[feature_name].txt`
- **变量**: [列出需要替换的变量，如 {input}, {context}]
- **版本**: v1.0

## 功能需求
- [需求1：具体描述]
- [需求2：具体描述]
- [需求3：具体描述]

## 数据流
```mermaid
graph LR
    A[输入] --> B[预处理]
    B --> C[LLM 调用]
    C --> D[后处理]
    D --> E[输出]
```

## API 端点（如果适用）
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/[feature] | 创建[资源] |
| GET | /api/[feature]/{id} | 获取[资源] |

## 错误处理
- **API 调用失败**：记录日志，返回友好错误信息，重试 1-2 次
- **超时处理**：设置 10-30 秒超时，避免长时间等待
- **成本控制**：限制单次请求 Token 数量，启用缓存

## 测试策略
### 单元测试
- 测试正常输入
- 测试边界情况
- 测试异常处理

### 集成测试
- 测试完整流程
- 测试与数据库集成
- 测试并发请求

### 提示词测试
- 测试 10 个不同场景
- 验证输出格式正确性
- 评估 Token 使用效率

## 成本估算
- **预估 Token/请求**：输入 100 + 输出 200 = 300 tokens
- **预估成本/请求**：约 ¥0.003（智谱 GLM-4.7）
- **预估日请求量**：100 次
- **月成本**：约 ¥9

## 实现

### 文件结构
```
src/
├── prompts/
│   └── [feature_name].txt          # 提示词模板
├── chains/
│   └── [feature_name]_chain.py     # LLM 调用链
├── api/
│   └── [feature_name]_routes.py    # API 路由
└── utils/
    └── llm_client.py               # LLM 客户端封装
```

### 关键函数
```python
# src/chains/[feature_name]_chain.py
async def process_[feature](input_data: dict) -> dict:
    """
    处理 [功能名称]

    Args:
        input_data: 输入数据

    Returns:
        处理结果
    """
    pass

# src/utils/llm_client.py
class LLMClient:
    """LLM 客户端"""
    async def call_llm(self, prompt: str, **kwargs) -> str:
        """调用 LLM"""
        pass
```
