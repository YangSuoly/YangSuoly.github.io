---
spec_version: "1.0"
type: api-endpoint
priority: medium
---

# [API 端点名称]

## 概述
[API 端点的功能描述]

## API 定义

### 端点信息
| 项目 | 值 |
|------|-----|
| 方法 | POST / GET / PUT / DELETE |
| 路径 | `/api/[resource]` |
| 认证 | Bearer Token / API Key |

### 请求格式
```json
{
  "field1": "value1",
  "field2": "value2"
}
```

### 响应格式
```json
{
  "success": true,
  "data": {},
  "message": "操作成功"
}
```

## 数据模型
```python
from pydantic import BaseModel

class RequestModel(BaseModel):
    """请求模型"""
    field1: str
    field2: int

class ResponseModel(BaseModel):
    """响应模型"""
    success: bool
    data: dict
    message: str
```

## 业务逻辑
1. **步骤1**：[具体说明]
2. **步骤2**：[具体说明]
3. **步骤3**：[具体说明]

## 错误处理
| 状态码 | 场景 | 处理方式 |
|--------|------|----------|
| 400 | 请求参数错误 | 返回详细错误信息 |
| 401 | 未认证 | 返回认证错误 |
| 404 | 资源不存在 | 返回资源未找到 |
| 500 | 服务器错误 | 记录日志并返回通用错误 |

## 测试用例
```python
def test_api_endpoint():
    """测试 API 端点"""
    response = client.post("/api/[resource]", json={})
    assert response.status_code == 200

def test_api_endpoint_validation():
    """测试参数验证"""
    response = client.post("/api/[resource]", json={"invalid": "data"})
    assert response.status_code == 400
```

## 实现

### 文件位置
```
src/api/
└── [resource]_routes.py
```

### 路由定义
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/[resource]", tags=["[Resource]"])

@router.post("/", response_model=ResponseModel)
async def create_[resource](request: RequestModel):
    """
    创建 [资源]

    Args:
        request: 请求数据

    Returns:
        响应数据
    """
    pass

@router.get("/{resource_id}", response_model=ResponseModel)
async def get_[resource](resource_id: str):
    """获取 [资源]"""
    pass
```
