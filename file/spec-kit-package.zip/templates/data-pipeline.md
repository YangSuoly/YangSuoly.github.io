---
spec_version: "1.0"
type: data-pipeline
priority: medium
---

# [数据管道名称]

## 概述
[数据管道的功能描述，例如：从 API 获取数据，经过清洗转换后存入数据库]

## 数据流

### 输入源
| 类型 | 格式 | 位置 |
|------|------|------|
| 文件 | CSV/JSON | data/input/ |
| API | JSON | https://api.example.com |
| 数据库 | SQL | PostgreSQL |

### 处理步骤
```mermaid
graph LR
    A[数据源] --> B[提取 Extract]
    B --> C[转换 Transform]
    C --> D[验证 Validate]
    D --> E[加载 Load]
    E --> F[输出]
```

## 数据模型
```python
from pydantic import BaseModel
from datetime import datetime

class DataModel(BaseModel):
    """数据模型"""
    id: str
    content: str
    metadata: dict
    created_at: datetime
```

## 处理逻辑

### 提取 (Extract)
- 从数据源读取原始数据
- 解析数据格式（JSON/CSV/数据库）
- 初始数据清洗

### 转换 (Transform)
- 数据格式统一
- 字段映射和重命名
- 数据清洗和去重
- 业务规则应用

### 验证 (Validate)
- 必填字段检查
- 数据类型验证
- 业务规则验证
- 异常数据处理

### 加载 (Load)
- 输出格式：JSON/CSV/Database
- 输出位置：data/output/
- 批量写入优化

## 错误处理
- **数据格式错误**：记录日志，跳过异常记录
- **网络错误**：指数退避重试（最多 3 次）
- **数据量过大**：分批处理，每批 1000 条

## 性能优化
- 并行处理多个数据源
- 批量操作减少 IO 次数
- 缓存中间结果
- 增量处理（只处理新增/变更数据）

## 测试用例
```python
def test_data_pipeline():
    """测试数据管道"""
    # 测试正常流程
    result = process_pipeline("test_source", "test_dest")
    assert result["success"] == True

    # 测试错误处理
    result = process_pipeline("invalid_source", "test_dest")
    assert result["success"] == False

def test_data_validation():
    """测试数据验证"""
    # 测试必填字段
    # 测试数据类型
    # 测试业务规则
    pass
```

## 实现

### 文件结构
```
src/
├── pipelines/
│   ├── extract.py     # 数据提取
│   ├── transform.py    # 数据转换
│   ├── validate.py     # 数据验证
│   └── load.py        # 数据加载
└── utils/
    └── data_helpers.py # 辅助函数
```

### 主要函数
```python
async def process_pipeline(source: str, destination: str) -> dict:
    """
    执行数据管道

    Args:
        source: 数据源标识
        destination: 输出位置

    Returns:
        处理结果统计
    """
    # 1. 提取数据
    raw_data = await extract(source)

    # 2. 转换数据
    transformed_data = transform(raw_data)

    # 3. 验证数据
    validated_data = validate(transformed_data)

    # 4. 加载数据
    result = await load(validated_data, destination)

    return result
```
