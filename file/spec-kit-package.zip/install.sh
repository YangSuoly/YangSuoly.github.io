#!/bin/bash
# Spec Kit 模板包快速安装脚本
#
# 使用方法：
#   cd /path/to/your/project
#   bash /path/to/spec-kit-package/install.sh

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_header() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# 获取脚本所在目录的绝对路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 获取当前工作目录（项目根目录）
PROJECT_DIR="$(pwd)"

print_header "Spec Kit 模板包安装向导"

print_info "模板包位置: $SCRIPT_DIR"
print_info "目标项目位置: $PROJECT_DIR"
echo ""

# 确认安装
read -p "是否在当前目录安装 Spec Kit 模板？(y/N) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_warning "安装已取消"
    exit 0
fi

# 步骤 1: 创建目录结构
print_header "步骤 1/4: 创建目录结构"

print_info "创建 .specify 目录..."
mkdir -p "$PROJECT_DIR/.specify/templates"
mkdir -p "$PROJECT_DIR/.specify/specs"

print_success "目录结构创建完成"
tree -L 2 "$PROJECT_DIR/.specify" 2>/dev/null || ls -R "$PROJECT_DIR/.specify"

echo ""

# 步骤 2: 复制模板文件
print_header "步骤 2/4: 复制模板文件"

print_info "复制规范模板..."
cp "$SCRIPT_DIR/templates/llm-feature.md" "$PROJECT_DIR/.specify/templates/"
cp "$SCRIPT_DIR/templates/api-endpoint.md" "$PROJECT_DIR/.specify/templates/"
cp "$SCRIPT_DIR/templates/data-pipeline.md" "$PROJECT_DIR/.specify/templates/"

print_success "模板文件复制完成"
ls -lh "$PROJECT_DIR/.specify/templates/"

echo ""

# 步骤 3: 创建配置文件
print_header "步骤 3/4: 创建配置文件"

if [ -f "$PROJECT_DIR/.specify/config.yaml" ]; then
    print_warning "配置文件已存在，跳过创建"
    print_info "如需重新配置，请编辑 .specify/config.yaml"
else
    print_info "创建配置文件..."
    cp "$SCRIPT_DIR/config.yaml" "$PROJECT_DIR/.specify/config.yaml"

    print_success "配置文件创建完成"
    print_warning "请根据项目需求编辑 .specify/config.yaml"
fi

echo ""

# 步骤 4: 验证安装
print_header "步骤 4/4: 验证安装"

print_info "检查文件..."
if [ -f "$PROJECT_DIR/.specify/templates/llm-feature.md" ] && \
   [ -f "$PROJECT_DIR/.specify/templates/api-endpoint.md" ] && \
   [ -f "$PROJECT_DIR/.specify/templates/data-pipeline.md" ] && \
   [ -f "$PROJECT_DIR/.specify/config.yaml" ]; then
    print_success "所有文件安装成功！"
else
    print_error "安装验证失败，请检查"
    exit 1
fi

echo ""

# 完成信息
print_header "安装完成！"

print_success "Spec Kit 模板包已成功安装到你的项目"
echo ""

print_info "下一步操作："
echo ""
echo "  1️⃣  编辑配置文件"
echo "     nano .specify/config.yaml"
echo ""
echo "  2️⃣  创建第一个规范"
echo "     cp .specify/templates/llm-feature.md .specify/specs/my-feature.md"
echo ""
echo "  3️⃣  结合 Claude Code 使用"
echo "     claude \"根据 .specify/specs/my-feature.md 生成代码\""
echo ""
echo "  📚 查看完整文档"
echo "     cat $SCRIPT_DIR/README.md"
echo ""

print_info "💡 小贴士："
echo "   - 模板文件位于: .specify/templates/"
echo "   - 规范文件位于: .specify/specs/"
echo "   - 配置文件位于: .specify/config.yaml"
echo ""

print_success "祝开发愉快！"
