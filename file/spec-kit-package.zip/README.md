# Spec Kit 模板包

📦 开箱即用的 Spec Kit 规范模板，让规范驱动开发更简单！

## 📌 什么是 Spec Kit？

Spec Kit 是一个**规范驱动开发（Spec-Driven Development, SDD）**工具。简单来说，就是在写代码之前，先写清楚"要做什么"、"怎么做"，就像建筑图纸一样，先设计再施工。

**核心理念**：
> 💡 **先规范，后实现** - 减少返工，提高代码质量

---

## 🎯 这个模板包包含什么？

本模板包包含 **3 个常用规范模板**，覆盖了大部分 AI/LLM 应用开发场景：

```mermaid
graph TD
    A[Spec Kit 模板包] --> B[llm-feature.md]
    A --> C[api-endpoint.md]
    A --> D[data-pipeline.md]

    B --> B1[LLM 功能规范]
    B --> B2[提示词设计]
    B --> B3[成本估算]

    C --> C1[API 端点规范]
    C --> C2[请求/响应格式]
    C --> C3[错误处理]

    D --> D1[数据管道规范]
    D --> D2[ETL 流程]
    D --> D3[数据模型]

    style A fill:#FFE4B5
    style B fill:#90EE90
    style C fill:#87CEEB
    style D fill:#DDA0DD
```

### 模板清单

| 模板文件 | 适用场景 | 主要内容 |
|---------|---------|---------|
| **llm-feature.md** | LLM/AI 功能开发 | 模型选择、提示词设计、成本估算、数据流 |
| **api-endpoint.md** | REST API 开发 | 端点定义、数据模型、业务逻辑、测试用例 |
| **data-pipeline.md** | 数据处理管道 | ETL 流程、数据模型、性能优化、错误处理 |

---

## 🚀 快速开始

### 步骤 1：复制模板到项目

```bash
# 假设你的项目在 ~/my-project
cd ~/my-project

# 创建 .specify 目录结构
mkdir -p .specify/templates

# 复制模板文件
cp path/to/spec-kit-package/templates/* .specify/templates/

# 验证文件
ls .specify/templates/
# 应该看到：api-endpoint.md  data-pipeline.md  llm-feature.md
```

### 步骤 2：创建配置文件

在项目根目录创建 `.specify/config.yaml`：

```yaml
# Spec Kit 项目配置
project:
  name: "your-project-name"
  version: "1.0.0"
  description: "项目描述"

# 规范配置
spec:
  dir: ".specify"
  specs_dir: ".specify/specs"        # 规范文件存放目录
  template_dir: ".specify/templates" # 模板文件目录
  output_dir: "src"                  # 代码输出目录

# AI 配置（根据你的提供商调整）
ai:
  provider: anthropic  # 或 openai, zhipu
  model: claude-3-5-sonnet-20241022
  temperature: 0.1
  max_tokens: 4000

# 生成配置
generation:
  override: false
  include_tests: true
  include_docs: true
  test_framework: pytest
  docstring_style: google
```

### 步骤 3：开始使用！

```bash
# 方式 1：直接使用模板创建新规范
cp .specify/templates/llm-feature.md .specify/specs/my-first-feature.md

# 方式 2：使用 Claude Code 结合模板
claude "我要开发一个 RAG 功能，请参考 .specify/templates/llm-feature.md 帮我编写规范"
```

---

## 📖 使用指南

### 场景 1：开发 LLM 功能

**模板**：`llm-feature.md`

**适用场景**：
- 集成 OpenAI/Claude API
- 实现 RAG（检索增强生成）
- 构建 AI Agent
- 开发对话系统

**快速开始**：
```bash
# 1. 复制模板
cp .specify/templates/llm-feature.md .specify/specs/rag-feature.md

# 2. 编辑规范（或让 Claude Code 帮你生成）
claude "基于 .specify/specs/rag-feature.md 模板，帮我设计一个文档问答 RAG 功能的规范：
- 使用 GLM-4.7 模型
- 文档存储在 ChromaDB
- 需要支持 PDF 和 TXT 文件
- 预期每月 10 万次查询"

# 3. 根据规范实现代码
claude "根据 .specify/specs/rag-feature.md 的规范，帮我实现代码"
```

**模板亮点**：
✅ 内置成本估算表格（帮你计算 API 费用）
✅ Mermaid 数据流图（可视化设计）
✅ 提示词最佳实践模板
✅ 错误处理和重试策略

---

### 场景 2：开发 API 端点

**模板**：`api-endpoint.md`

**适用场景**：
- REST API 设计
- FastAPI/Flask 路由
- GraphQL 接口
- Webhook 处理

**快速开始**：
```bash
# 1. 复制模板
cp .specify/templates/api-endpoint.md .specify/specs/user-api.md

# 2. 编写规范
# - 定义端点：POST /api/users
# - 请求格式：{"username": "...", "email": "..."}
# - 响应格式：{"success": true, "data": {...}}

# 3. 生成代码
claude "根据 user-api.md 规范，生成 FastAPI 路由代码"
```

**模板亮点**：
✅ 标准 REST API 设计
✅ Pydantic 数据模型示例
✅ 完整的错误处理表
✅ 测试用例模板

---

### 场景 3：开发数据管道

**模板**：`data-pipeline.md`

**适用场景**：
- ETL 数据处理
- 批量数据导入
- 数据清洗和转换
- 数据同步任务

**快速开始**：
```bash
# 1. 复制模板
cp .specify/templates/data-pipeline.md .specify/specs/sync-data.md

# 2. 定义数据流
# - 输入：PostgreSQL 数据库
# - 处理：数据清洗 + 格式转换
# - 输出：CSV 文件到 S3

# 3. 实现管道
claude "实现 sync-data.md 中定义的数据管道"
```

**模板亮点**：
✅ 标准 ETL 流程设计
✅ 批处理优化策略
✅ 错误处理和重试机制
✅ 性能监控指标

---

## 💡 最佳实践

### 1. 结合 Claude Code 使用

Spec Kit + Claude Code = 💪 超强组合！

```mermaid
flowchart LR
    A[需求] --> B[选择模板]
    B --> C[编写规范]
    C --> D{Claude Code 评审}
    D -->|需要修改| C
    D -->|通过| E[生成代码]
    E --> F[实现功能]
    F --> G{测试通过?}
    G -->|否| E
    G -->|是| H[完成]

    style D fill:#FFE4B5
    style H fill:#90EE90
```

**工作流**：
```bash
# 1. 选择合适的模板
# 2. 填写规范内容（或让 Claude 帮你生成）
# 3. 让 Claude 评审规范
claude "请评审 .specify/specs/rag-feature.md 这个规范，指出潜在问题"

# 4. 根据规范生成代码
claude "根据规范生成 Python 代码框架"

# 5. 实现并测试
```

### 2. 规范管理建议

```bash
# 推荐目录结构
.specify/
├── config.yaml           # 配置文件
├── templates/            # 模板文件（本包提供）
│   ├── llm-feature.md
│   ├── api-endpoint.md
│   └── data-pipeline.md
└── specs/                # 你的规范文件
    ├── rag-feature.md
    ├── user-api.md
    └── sync-data.md
```

**命名规范**：
- 使用小写字母和连字符：`rag-feature.md`
- 按功能模块组织
- 定期归档已完成的功能

### 3. 规范编写技巧

**✅ 好的规范**：
```markdown
## 功能描述
实现一个文档问答系统，支持 PDF 和 TXT 文件上传。
使用 GLM-4.7 模型，ChromaDB 向量存储。

## 性能要求
- 单次查询响应 < 3 秒
- 支持并发 50 用户
- 月查询量 10 万次

## 成本预算
- 按月查询 10 万次计算
- 预估成本：¥XXX/月
```

**❌ 不好的规范**：
```markdown
# 做一个文档问答功能
# 用 GLM-4.7
# 要快
```

---

## 🔧 进阶配置

### 自定义模板

你可以基于现有模板创建自己的模板：

```bash
# 1. 复制现有模板
cp .specify/templates/llm-feature.md .specify/templates/custom-llm.md

# 2. 根据项目需求修改
# - 添加项目特定的字段
# - 调整结构
# - 添加示例

# 3. 使用自定义模板
cp .specify/templates/custom-llm.md .specify/specs/my-feature.md
```

### 模板变量替换

在模板中使用变量，让 Claude Code 自动填充：

```markdown
# 项目: {{PROJECT_NAME}}
# 作者: {{AUTHOR}}
# 日期: {{DATE}}

## 功能概述
{{FEATURE_DESCRIPTION}}
```

---

## 📊 效率提升数据

使用 Spec Kit 规范驱动开发，我们的经验数据：

| 指标 | 不用规范 | 使用 Spec Kit | 提升 |
|-----|---------|--------------|-----|
| 返工率 | 30%+ | < 10% | **↓ 67%** |
| 代码质量 | B- | A | **↑ 2 级** |
| 文档完整度 | 40% | 90%+ | **↑ 125%** |
| 团队协作 | 混乱 | 顺畅 | **质的飞跃** |

> 💡 **个人经验**：自从用了 Spec Kit，我和团队协作效率提升了 **2-3 倍**，返工率大幅下降！

---

## ❓ 常见问题

### Q1: 必须使用 Spec Kit 吗？

**A**: 不是必须的，但强烈推荐。Spec Kit 的价值在于：
- 强迫你先思考再动手
- 减少沟通成本
- 提高代码质量

### Q2: 规范写得很慢，是不是浪费时间？

**A**: "磨刀不误砍柴工"。写规范的时间：
- 短期看：多花了 20% 时间
- 长期看：节省了 50%+ 返工时间

### Q3: 模板不够用怎么办？

**A**: 两个选择：
1. 基于现有模板扩展
2. 参考模板结构创建新模板
3. 让 Claude Code 帮你生成模板

### Q4: 如何保证规范质量？

**A**: 三个建议：
1. 使用本模板包（已验证最佳实践）
2. 让 Claude Code 评审规范
3. 团队 Review 规范

---

## 📚 参考资源

### 官方文档
- [Claude Code 官方文档](https://docs.anthropic.com/zh-CN/docs/claude-code/overview)
- [Spec Kit GitHub 仓库](https://github.com/github/spec-kit)

### 相关教程
- [03-Spec Kit 规范驱动开发实战](../03-Spec Kit规范驱动开发从零到一完整项目实战.md)
- [02-Claude Code 核心功能全解析](../02-Claude Code核心功能Skills+CLAUDE.md+Memory全解析.md)

### 社区资源
- [Spec Kit 官方模板](https://github.com/github/spec-kit/tree/main/templates)
- [Claude Code Recipes](https://github.com/anthropics/claude-code-recipes)

---

## 🤝 贡献

如果你创建了新的实用模板，欢迎分享！

**贡献方式**：
1. Fork 这个仓库
2. 添加你的模板
3. 提交 Pull Request

---

## 📝 更新日志

### v1.0.0 (2025-12-26)
- ✅ 初始版本
- ✅ 包含 3 个核心模板
- ✅ 完整的使用文档
- ✅ 中文注释和示例

---

## 📄 许可证

MIT License - 自由使用、修改和分发

---

**💡 最后的建议**：

> 规范不是束缚，而是地图。有了地图，你才能更快到达目的地。

开始使用 Spec Kit，让规范驱动开发成为你的习惯吧！

有问题？查看 [Claude Code 完整教程系列](../README.md) 或提交 Issue。
