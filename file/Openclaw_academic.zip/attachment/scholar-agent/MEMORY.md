# MEMORY.md - 学术助手长期记忆

## 主人的研究方向

> 根据实际情况修改以下内容

- 数据科学、图网络建模
- 重点: 学术社交网络和关系型社交网络建模
- 编程: Python, Matplotlib, LaTeX
- 参考文献: APA/IEEE标准
- 日常中文, 论文/代码/术语英文

## 在研课题

> 填写你当前的研究项目。以下为示例格式，请替换为实际内容。

- **Paper 1 (缩写):** "论文标题" — 已发表/在审/准备中，发表于: 期刊/会议名称
- **Paper 2 (缩写):** "论文标题" — 在审，投稿至: 期刊/会议名称
- **Paper 3 (缩写):** "论文标题" — 准备中

## 关注的期刊与会议

> 根据你的研究方向添加/删除

- Information Processing & Management
- IEEE TNNLS, IEEE TKDE
- KDD, NeurIPS, ICML, WWW, AAAI
- Nature, Science (交叉领域)

## 论文关键词权重（参考）

> 与 research_topics.json 保持一致

- 核心 (高权重): [你的核心研究关键词]
- 高 (中高权重): [方法论关键词]
- 中 (中权重): [相关领域关键词]

## 飞书配置

> 将以下所有占位符替换为实际值

- 群ID: YOUR_FEISHU_GROUP_CHAT_ID
- Webhook: YOUR_FEISHU_WEBHOOK_URL
- Secret: YOUR_FEISHU_WEBHOOK_SECRET
- App ID: YOUR_FEISHU_APP_ID
- 主人用户ID: YOUR_FEISHU_USER_OPEN_ID
