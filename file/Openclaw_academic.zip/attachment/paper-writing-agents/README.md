# 多智能体论文写作系统 — 配置模板包

基于 OpenClaw 平台的 7 Agent 论文写作协作系统。Planner 绑定飞书群作为唯一交互入口，其余 6 个子智能体在后台运行，结果统一经由 Planner 转发给用户。

## 文件结构

```
paper-writing-agents/
├── README.md                          # 本文档
├── openclaw-additions.json            # 需合并到 openclaw.json 的 agents + bindings 片段
└── agents/
    ├── planner/
    │   ├── SOUL.md                    # Planner 核心指令（通信架构、工作流驱动）
    │   ├── USER.md                    # 用户研究背景上下文
    │   └── AGENTS.md                  # Workspace 规则（所有 Agent 通用）
    ├── ideator/
    │   ├── SOUL.md
    │   └── USER.md
    ├── critic/
    │   ├── SOUL.md
    │   └── USER.md
    ├── surveyor/
    │   ├── SOUL.md
    │   └── USER.md
    ├── coder/
    │   ├── SOUL.md
    │   └── USER.md
    ├── writer/
    │   ├── SOUL.md
    │   └── USER.md
    └── reviewer/
        ├── SOUL.md
        └── USER.md
```

---

## 快速配置指南

### Step 1：修改通用研究背景

所有 7 个 `USER.md` 共享相同的"研究背景"部分，统一替换以下占位符：

| 占位符 | 替换为 |
|--------|--------|
| `YOUR_RESEARCH_DIRECTION_1` | 你的核心研究方向，如"图神经网络" |
| `YOUR_RESEARCH_DIRECTION_2` | 第二个方向，如"知识图谱" |
| `YOUR_PROJECT_1` / `_2` / `_3` | 在研项目名称和简介 |
| `YOUR_TARGET_VENUES` | 目标会议/期刊列表 |
| `YOUR_TECH_STACK` | 你的主要开发工具和框架 |

> 建议：先改好一份 `agents/planner/USER.md`，再复制研究背景部分到其余 6 份。

### Step 2：配置 openclaw.json

将 `openclaw-additions.json` 中的内容**合并**到你的 `~/.openclaw/openclaw.json`：

- `agents.list` 数组：追加 7 个 Agent 条目
- `channels.feishu.bindings`：追加 planner 的飞书群绑定
- `channels.feishu.groupAllowFrom`：追加论文写作群 ID

**注意**：替换所有 `YOUR_*` 占位符（workspace 路径、飞书群 ID 等）。

### Step 3：部署 Workspace 文件

每个 Agent 需要一个独立 workspace 目录，将对应模板文件复制进去：

```bash
# 示例：部署 planner
WORKSPACE=~/.openclaw/workspace-planner
mkdir -p "$WORKSPACE/memory"
cp agents/planner/SOUL.md   "$WORKSPACE/"
cp agents/planner/USER.md   "$WORKSPACE/"
cp agents/planner/AGENTS.md "$WORKSPACE/"

# 其余 6 个 Agent（无需 AGENTS.md，继承 planner 的通用版本即可，或自行复制）
for agent in ideator critic surveyor coder writer reviewer; do
  mkdir -p ~/.openclaw/workspace-$agent/memory
  cp agents/$agent/SOUL.md  ~/.openclaw/workspace-$agent/
  cp agents/$agent/USER.md  ~/.openclaw/workspace-$agent/
  # 可选：复制通用 AGENTS.md
  cp agents/planner/AGENTS.md ~/.openclaw/workspace-$agent/
done
```

### Step 4：创建飞书论文写作群

1. 在飞书中创建群组，名称建议：`Scholar Seminer`（或你喜欢的名称）
2. 将 OpenClaw 机器人添加进群
3. 获取群 ID（群设置 → 机器人 → 复制 group ID，格式 `oc_xxxxxx`）
4. 替换 `openclaw-additions.json` 中的 `YOUR_FEISHU_GROUP_CHAT_ID`
5. 同时更新 `groupAllowFrom` 数组

### Step 5：验证

重启 OpenClaw 后，在飞书论文写作群发送：

```
帮我评估一个 idea：[你的想法]
```

Planner 自动接收并调度 Ideator + Critic，完成后在群里汇报结果。

---

## Agent 角色速览

| Agent | 职责 | 与用户交互 | 输出结尾标记 |
|-------|------|-----------|------------|
| 🧠 Planner | 统筹协调、用户沟通、进度追踪 | ✅ 直接（飞书群） | 汇报 + 询问用户 |
| 💡 Ideator | Idea 生成、ACE 评分、Contribution Statement | ❌ 后台 | ✅ 任务完成 |
| 🎯 Critic | SHARP 品鉴、反模式检测、Bar Test | ❌ 后台 | ✅ 品鉴完成，SHARP总分: X/25 |
| 📚 Surveyor | 文献调研、Research Gap、SOTA 对比 | ❌ 后台 | ✅ 任务完成 |
| 💻 Coder | 算法实现、实验执行、消融分析 | ❌ 后台 | ✅ 任务完成 |
| ✍️ Writer | 论文撰写、LaTeX 排版、BibTeX | ❌ 后台 | ✅ 写作完成 |
| 🔍 Reviewer | 内部审稿、Rebuttal 策略 | ❌ 后台 | ✅ 审稿完成 |

---

## 常用触发指令（飞书论文写作群）

```
# 完整论文流水线
启动 paper-pipeline 工作流，目标会议 [VENUE]，DDL [YYYY-MM-DD]
研究方向：[你的方向]

# 快速 Idea 评估
帮我评估这个 idea：[描述]

# 头脑风暴
来一场 brainstorm，方向是 [主题]

# 文献调研
帮我调研 [主题] 的最新方法

# Rebuttal
我收到了 [VENUE] 的审稿意见，帮我准备 rebuttal：[粘贴审稿意见]

# 论文撰写
帮我撰写 [VENUE] 论文的 [章节名]，题目是：[论文题目]
```
