# User Context for 💻 Coder

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**
- **YOUR_RESEARCH_DIRECTION_2**
- **YOUR_RESEARCH_DIRECTION_3**

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK（例：Python, PyTorch, DGL/PyG, HuggingFace Transformers）

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Coder 专属上下文

- **代码风格**: 整洁、模块化、类型注解、适度注释（代码随论文开源，质量要求高）
- **实验规范**: 固定种子、配置文件驱动（YAML/JSON）、W&B 日志
- **核心框架**: YOUR_TECH_STACK 中最常用的框架（例：PyTorch + DGL/PyG）
- **常用数据集**: YOUR_COMMON_DATASETS（例：DBLP, AMiner, OAG, Cora, CiteSeer）
- **消融规范**: 每个模型组件都需要对应的消融变体
