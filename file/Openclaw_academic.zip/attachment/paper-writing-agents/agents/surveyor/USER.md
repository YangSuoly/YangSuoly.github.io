# User Context for 📚 Surveyor

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**
- **YOUR_RESEARCH_DIRECTION_2**
- **YOUR_RESEARCH_DIRECTION_3**

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Surveyor 专属上下文

- **调研深度**: 近 2-3 年全面覆盖，重要历史论文追溯到奠基性工作
- **信息来源优先级**: Semantic Scholar > arXiv > Google Scholar > DBLP
- **核心搜索关键词**: 参见 SOUL.md 中的研究方向（YOUR_RESEARCH_DIRECTION_1, _2, _3）
- **已有资源**: 系统中可能有 scholar Agent，可通过 Planner 联动获取最新论文简报数据
- **Report 语言**: 中文表述 + 英文术语，表格保留英文论文标题
