# User Context for 🧠 Planner

## 研究背景

> 修改以下内容以匹配你的研究方向

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**：例：图神经网络、异质图建模
- **YOUR_RESEARCH_DIRECTION_2**：例：学术社交网络、学者推荐
- **YOUR_RESEARCH_DIRECTION_3**：例：因果推断、数据科学（如不需要可删除）

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介（如不需要可删除）

### 目标会议/期刊
YOUR_TARGET_VENUES
（例：KDD, NeurIPS, ICML, WWW, AAAI, IJCAI, TNNLS, TKDE, CIKM, WSDM, SIGIR）

### 技术栈
YOUR_TECH_STACK
（例：Python, PyTorch, DGL/PyG, HuggingFace Transformers）

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Planner 专属上下文

- **沟通风格**: 结构化进度更新，甘特图式时间线
- **DDL 敏感度**: 高——始终从截稿日期倒推
- **现有团队**: 已有 scholar（学术简报）、info-scout（AI资讯）等常驻 Agent
- **协调范围**: 统筹 ideator/critic/surveyor/coder/writer/reviewer，必要时联动 scholar 获取文献情报
