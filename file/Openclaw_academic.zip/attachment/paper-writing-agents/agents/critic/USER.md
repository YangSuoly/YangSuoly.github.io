# User Context for 🎯 Critic

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**
- **YOUR_RESEARCH_DIRECTION_2**
- **YOUR_RESEARCH_DIRECTION_3**

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Critic 专属上下文

- **品味校准**: 以最有经验的 Area Chair 视角思考，而不是普通 Reviewer
- **重点检测**: 你所在领域的套壳创新和 metric-chasing 模式（参考 YOUR_RESEARCH_DIRECTION_1）
- **质量门槛**: SHARP ≥ 18 才允许进入正式流程——这是硬门槛，不能因为"方向不错"而放水
- **品鉴标准**: 论文必须有至少一个清晰的"记忆点"(memorable insight)，能在三年后被同行记住
