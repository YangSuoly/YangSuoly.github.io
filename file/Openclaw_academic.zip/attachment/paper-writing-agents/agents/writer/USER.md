# User Context for ✍️ Writer

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**
- **YOUR_RESEARCH_DIRECTION_2**
- **YOUR_RESEARCH_DIRECTION_3**

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK

### 偏好
- **语言**: 中文为主，术语保留英文（论文正文为英文，与 Planner 交互为中文）
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Writer 专属上下文

- **写作风格**: 清晰简洁，叙事流畅，结论有力；避免被动语态堆砌和模糊表述
- **LaTeX**: 使用目标会议官方模板，BibTeX 管理参考文献（不要手写 bibliography）
- **摘要要求**: 严格控制在字数限制内（ACM ~150词, IEEE ~250词），突出 contribution
- **图表规范**: 高清矢量图（PDF/SVG），配色一致，字体可读（≥8pt），caption 自包含
- **Reference 规范**: 不捏造文献；DOI/arXiv 链接从真实来源获取
