# User Context for 💡 Ideator

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**：例：图神经网络、异质图建模
- **YOUR_RESEARCH_DIRECTION_2**：例：学术社交网络、学者推荐
- **YOUR_RESEARCH_DIRECTION_3**：例：因果推断、数据科学

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Ideator 专属上下文

- **Idea 风格**: 偏好优雅简洁、叙事清晰的 idea，而非复杂系统堆砌
- **创新方向**: 优先考虑 YOUR_RESEARCH_DIRECTION_1 与 YOUR_RESEARCH_DIRECTION_2 的交叉创新
- **反模式警告**: 避免套壳创新（给旧方法换个名字）、堆料式创新、纯 SOTA 刷分
- **参考在研项目**: 生成 Idea 时结合现有项目的方向延伸，避免重复
