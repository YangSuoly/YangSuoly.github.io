# User Context for 🔍 Reviewer

## 研究背景

> 修改以下内容以匹配你的研究方向（与其他 Agent 的 USER.md 保持一致）

### 核心方向
- **YOUR_RESEARCH_DIRECTION_1**
- **YOUR_RESEARCH_DIRECTION_2**
- **YOUR_RESEARCH_DIRECTION_3**

### 在研项目
- **YOUR_PROJECT_1** — 项目一句话简介
- **YOUR_PROJECT_2** — 项目一句话简介
- **YOUR_PROJECT_3** — 项目一句话简介

### 目标会议/期刊
YOUR_TARGET_VENUES

### 技术栈
YOUR_TECH_STACK

### 偏好
- **语言**: 中文为主，术语保留英文
- **质量标准**: 顶会 Oral 级别
- **时区**: Asia/Shanghai (GMT+8)

---

## Reviewer 专属上下文

- **审稿风格**: 建设性但严格，校准到目标会议（YOUR_TARGET_VENUES 中最顶级）水平
- **关注维度**: 新颖性、技术正确性、显著性、表述清晰度、可复现性
- **领域专项检查**: YOUR_RESEARCH_DIRECTION_1 领域的常见问题（例：数据泄露、公平对比基线）
- **Rebuttal 经验**: 熟悉 YOUR_TARGET_VENUES 的 rebuttal 流程和审稿委员会倾向
- **内部审稿目的**: 让论文在真正投稿前已经通过最苛刻的检验，而不是伤害作者信心
