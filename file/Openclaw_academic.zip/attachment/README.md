# 学术智能体模板包

基于 OpenClaw 平台的学术论文自动监控与推荐系统模板。导入后即可运行每 3 天一次的论文简报推送。

## 包含内容

```
attachment/
├── README.md                          # 本文档
├── scholar-agent/                     # Scholar Agent 人设文件
│   ├── SOUL.md                        # 核心指令与研究聚焦
│   ├── IDENTITY.md                    # 身份定义
│   ├── MEMORY.md                      # 长期记忆（研究方向、在研课题）
│   ├── USER.md                        # 用户信息
│   └── AGENTS.md                      # Session 初始化规则
├── academic-briefing/                 # Academic Briefing Skill 配置
│   ├── config/
│   │   ├── config.json                # 飞书推送配置（含 webhook）
│   │   └── .env.example              # 飞书 App 凭证模板
│   └── references/
│       ├── research_topics.json       # 研究关键词分层配置
│       └── journal_rss_feeds.json     # 期刊 RSS 源（24 个期刊 + arXiv 分类）
├── rss-monitor/                       # RSS Monitor Skill 配置
│   └── config/
│       └── config.json                # 飞书推送配置
└── cron/
    └── academic-briefing-cron.json    # Cron 任务定义模板
```

---

## 快速配置指南

### Step 1: 准备飞书凭证

1. 登录[飞书开放平台](https://open.feishu.cn/)，创建一个企业自建应用
2. 在应用管理页面找到 **App ID** 和 **App Secret**
3. 启用以下 API 权限：
   - `im:message` — 发送消息
   - `docx:document` — 创建文档
   - `drive:drive` — 管理文件权限
4. 创建一个飞书群，添加群机器人，获取 **Webhook URL** 和 **Webhook Secret**
5. 获取你的飞书 **Open ID**（个人用户 ID，格式 `ou_xxxxxxxx`）：
   - 进入[飞书开放平台 API 调试工具](https://open.feishu.cn/api-explorer/)
   - 调用 `GET /open-apis/contact/v3/users/me` 获取自己的 open_id

---

### Step 2: 配置 Scholar Agent

将 `scholar-agent/` 目录下的文件复制到你的 Scholar Agent 工作目录（如 `~/clawd/agents/scholar/`）。

**MEMORY.md** — 填写你的研究方向和在研课题：
```markdown
## 飞书配置
- 群ID: YOUR_FEISHU_GROUP_CHAT_ID          ← 替换为实际群 ID
- Webhook: YOUR_FEISHU_WEBHOOK_URL          ← 替换为实际 Webhook URL
- Secret: YOUR_FEISHU_WEBHOOK_SECRET        ← 替换
- App ID: YOUR_FEISHU_APP_ID               ← 替换
- 主人用户ID: YOUR_FEISHU_USER_OPEN_ID     ← 替换
```

**USER.md** — 填写你的姓名和称呼方式。

---

### Step 3: 配置 Academic Briefing Skill

前提：已安装 `academic-briefing` skill（参见 OpenClaw 文档）。

1. **复制配置文件**：
   ```bash
   cp academic-briefing/config/config.json ~/.agents/skills/academic-briefing/config/config.json
   cp academic-briefing/config/.env.example ~/.agents/skills/academic-briefing/.env
   ```

2. **编辑 config.json**，替换所有 `YOUR_*` 占位符：
   ```json
   {
     "feishu_webhook": "https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK_ID",
     "feishu_secret": "YOUR_FEISHU_WEBHOOK_SECRET",
     "feishu_user_id": "YOUR_FEISHU_USER_OPEN_ID"
   }
   ```

3. **编辑 .env**，填写 App 凭证：
   ```env
   FEISHU_APP_ID=cli_xxxxxxxxxxxxxxxx
   FEISHU_APP_SECRET=your_app_secret_here
   ```

4. **复制研究关键词配置**（按需修改）：
   ```bash
   cp academic-briefing/references/research_topics.json ~/.agents/skills/academic-briefing/references/
   cp academic-briefing/references/journal_rss_feeds.json ~/.agents/skills/academic-briefing/references/
   ```

5. **根据你的研究方向修改关键词**（`research_topics.json`）：
   - `core.keywords` — 你的核心研究关键词（权重最高）
   - `method.keywords` — 你常用的方法论关键词
   - `related.keywords` — 相关领域关键词
   - `exclude_keywords` — 要排除的无关领域
   - `boost_venues` — 你关注的顶会/顶刊

---

### Step 4: 配置 Cron 定时任务

1. **复制 cron 配置**：
   ```bash
   cp cron/academic-briefing-cron.json ~/.openclaw/cron/
   ```

2. **合并到 jobs.json**：将 `academic-briefing-cron.json` 中的 JSON 对象添加到 `~/.openclaw/cron/jobs.json` 的 `jobs` 数组中。

3. **替换占位符**：
   - `YOUR_FEISHU_GROUP_CHAT_ID` → 实际群聊 ID（格式 `oc_xxxxxxxx`）

4. **调整 cron 表达式**（可选）：
   - `"0 9 */3 * *"` = 每 3 天上午 9:00
   - `"0 9 * * 1"` = 每周一上午 9:00

---

### Step 5: 注册 Scholar Agent（openclaw.json）

在 `~/.openclaw/openclaw.json` 的 `agents` 数组中添加：

```json
{
  "id": "scholar",
  "workspace": "/path/to/your/scholar/workspace"
}
```

---

### Step 6: 测试运行

```bash
# 进入 skill 目录
cd ~/.agents/skills/academic-briefing
source .venv/bin/activate

# 先初始化（清空已推送记录）
python3 scripts/academic_monitor.py --init

# 预览模式（不推送，验证采集是否正常）
python3 scripts/academic_monitor.py --dry-run --days 7

# 采集并输出 JSON（查看论文评分结果）
python3 scripts/academic_monitor.py --collect --output /tmp/test_collect.json --days 7
cat /tmp/test_collect.json | python3 -m json.tool | head -100

# 降级模式（直接推送，无 AI 分析）
python3 scripts/academic_monitor.py --push --days 7
```

---

## 配置参数说明

### research_topics.json 评分机制

| 层级 | 权重 | 说明 |
|------|------|------|
| `core` | +5/个 | 核心研究方向关键词 |
| `method` | +4/个 | 方法论关键词 |
| `related` | +2/个 | 相关领域关键词 |
| `exclude_keywords` | -3/个 | 排除无关领域 |
| `boost_venues` 匹配 | +3 | 顶会/顶刊加分 |
| `boost_authors` 匹配 | +2 | 关注作者加分 |
| 非 arXiv 来源 | +2 | 期刊论文加分 |

**星级映射**：≥10分 → ⭐⭐⭐⭐⭐，≥6分 → ⭐⭐⭐⭐，≥3分 → ⭐⭐⭐，≥1分 → ⭐⭐

### 三步 Agent-Native 分析流程

```
Step 1: --collect  → Python 脚本采集+评分 → /tmp/academic_collect.json
Step 2: Agent 原生分析 → 逐篇 AI 深度分析  → /tmp/academic_analysis.json
Step 3: --push-results → Python 脚本推送飞书卡片 + 文档 + 私信
```

Agent 自身即为 AI 模型，无需配置额外 LLM API。

---

## 常见问题

**Q: 我没有 OpenClaw 的 scholar agent，只想运行脚本怎么办？**
使用降级模式：`python3 scripts/academic_monitor.py --push`，跳过 AI 分析直接推送元数据。

**Q: arXiv 采集数量为 0？**
arXiv 周末不更新，建议设置 `--days 7`。

**Q: 飞书卡片推送失败？**
检查 config.json 中的 webhook URL 和 secret 是否正确。卡片超过 28KB 时会自动减少论文数量。

**Q: 如何添加更多期刊 RSS 源？**
在 `journal_rss_feeds.json` 的 `journals` 数组中添加条目，格式为 `{"name": "期刊名", "url": "RSS URL", "category": "分类"}`。

**Q: 如何修改推送频率？**
编辑 `~/.openclaw/cron/jobs.json` 中对应条目的 `schedule.expr` 字段。

---

> 基于 OpenClaw 平台 + Scholar Agent + Academic Briefing Skill v3 (Agent-Native)
