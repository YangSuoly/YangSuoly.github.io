# Claude Code Skills 配置包

这是教程中提到的常用 Skills 配置文件，可以直接复制到你的项目中使用。

## 使用方法

### 方法一：复制到项目目录

```bash
# 复制所有 Skills 到项目根目录
cp -r skills-package/* /your-project/.claude/skills/

# 验证配置
ls -la /your-project/.claude/skills/
```

### 方法二：复制到全局目录

```bash
# 复制到全局 Claude Code 配置目录
cp -r skills-package/* ~/.claude/skills/

# 验证配置
ls -la ~/.claude/skills/
```

## 包含的 Skills

- **code-review**: 代码审查专家，检查质量、安全性和最佳实践
- **test-gen**: 测试用例生成器，自动生成单元测试和集成测试
- **doc-gen**: 文档生成助手，为代码生成完整的文档注释
- **todo-sync**: 任务同步器，同步待办事项到 TODO.md
- **llm-prompt-review**: 提示词优化师，审查 LLM 提示词的质量和安全性

## 目录结构

```
skills-package/
├── code-review/SKILL.md
├── test-gen/SKILL.md
├── doc-gen/SKILL.md
├── todo-sync/SKILL.md
├── llm-prompt-review/SKILL.md
└── README.md
```

## 验证配置

启动 Claude Code 后，可以通过以下方式验证：

```bash
# 启动 Claude Code
claude

# 查看可用技能
/help

# 测试使用
"请帮我审查 src/utils/helpers.py 的代码质量"
```

如果 Claude 自动调用了相应的 Skill，说明配置成功！

## 注意事项

1. **Skills 是 model-invoked**：不需要手动调用，只需描述你的需求，Claude 会自动匹配合适的 Skill
2. **描述要清晰**：使用"请审查代码"、"生成测试"等关键词，帮助 Claude 匹配 Skill
3. **重启生效**：添加新 Skill 后，重启 Claude Code 才能识别
