---
name: todo-sync
description: "将当前的待办事项同步到 TODO.md 文件中"
license: MIT
---

# 技能：任务同步

自动将当前的待办事项同步到 TODO.md 文件中。

## 输出格式

```markdown
# 项目待办事项

> 最后更新：时间戳

## 进行中
- [ ] 任务描述

## 待处理
- [ ] 任务描述

## 已完成
- [x] 任务描述
```
