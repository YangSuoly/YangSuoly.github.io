---
name: doc-gen
description: "为代码生成完整的文档注释和 API 文档"
license: MIT
---

# 技能：文档生成

为代码生成完整的文档注释和 API 文档。

## 文档风格

- Python：Google Style Docstring
- JavaScript/TypeScript：JSDoc
- Go：Go Doc

## 文档内容

每个函数/类必须包含：
1. 功能描述
2. 参数说明（Args/Parameters）
3. 返回值说明（Returns）
4. 异常说明（Raises/Throws）
5. 使用示例（Examples）
