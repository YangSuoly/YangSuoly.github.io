---
name: test-gen
description: "为代码自动生成单元测试和集成测试"
license: MIT
---

# 技能：测试生成

为代码生成完整的单元测试和集成测试。

## 测试类型

- 正常情况测试
- 边界情况测试
- 异常处理测试
- 覆盖率目标建议

## 输出格式

使用标准测试框架（pytest/unittest/jest），生成可运行的测试代码。

每个测试函数需要：
1. 清晰的函数名（test_xxx）
2. 完整的 docstring
3. 断言（assert）
